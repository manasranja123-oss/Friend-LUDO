# Friend Ludo — Android starter project

This is an early Android Studio starter/prototype for a room-code Ludo game. It is **not yet a finished or Play Store-ready game**.

## Current prototype
- Android app shell and home screen
- Player name input
- Create Room generates a six-digit demo ID
- Join Room ID screen flow
- Prototype board and demo dice/move counter

## Important limitations
- Room IDs are currently generated locally; different phones do not yet share rooms.
- The board is a placeholder, not the complete classic Ludo board.
- Full token paths, legal move validation, six-to-enter rules, safe squares, captures, win detection, reconnection and anti-cheat checks still need implementation.
- Firebase is included as a dependency but has not been configured.
- No signed APK/AAB is included, and this project has not been built or tested on a device.

## Set up online rooms
1. Open the project in Android Studio.
2. Create a Firebase project at https://console.firebase.google.com/.
3. Add an Android app with package name `com.friendludo.app`.
4. Download `google-services.json` and place it in the `app/` directory.
5. Enable Firebase Authentication (anonymous sign-in) and Realtime Database.
6. Configure secure Realtime Database rules before testing. Do not publish with open public read/write rules.
7. Implement server-authoritative room creation/joining and turn validation before public release.

## Build for Play Store
Use Android Studio to sync/build, test on multiple physical devices, then create a signed Android App Bundle (AAB). Before publishing, add app icon, privacy policy, support contact, data-safety declarations, content rating, and store listing. Review current Google Play requirements.
