package com.friendludo.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Navy = Color(0xFF172554)
private val Red = Color(0xFFEF4444)
private val Blue = Color(0xFF3B82F6)
private val Green = Color(0xFF22C55E)
private val Yellow = Color(0xFFFACC15)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { FriendLudoApp() } }
    }
}

@Composable
fun FriendLudoApp() {
    var screen by remember { mutableStateOf("home") }
    var roomId by remember { mutableStateOf("") }
    var playerName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Create a room or enter your friend's Room ID.") }
    var dice by remember { mutableIntStateOf(1) }
    var currentTurn by remember { mutableIntStateOf(0) }
    var players by remember { mutableStateOf(listOf<String>()) }
    var tokens by remember { mutableStateOf(listOf(0, 0, 0, 0)) }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF4F7FB)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("FRIEND LUDO", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Navy)
            Text("Play together. Anywhere.", color = Color.DarkGray)

            if (screen == "home") {
                Spacer(Modifier.height(20.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Your player name", fontWeight = FontWeight.Bold, color = Navy)
                        OutlinedTextField(value = playerName, onValueChange = { playerName = it.take(16) }, label = { Text("Enter name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (playerName.isBlank()) status = "Please enter your name first."
                            else {
                                roomId = (100000..999999).random().toString()
                                players = listOf(playerName)
                                status = "Room created on this demo. Share ID $roomId with your friends. Online room syncing needs Firebase setup."
                                screen = "lobby"
                            }
                        }, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("CREATE ROOM") }
                        HorizontalDivider()
                        OutlinedTextField(value = roomId, onValueChange = { roomId = it.filter(Char::isDigit).take(6) }, label = { Text("6-digit Room ID") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (playerName.isBlank()) status = "Please enter your name first."
                            else if (roomId.length != 6) status = "Enter a valid 6-digit Room ID."
                            else { status = "Join screen opened for room $roomId. Real online joining activates after Firebase setup."; players = listOf(playerName); screen = "lobby" }
                        }, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))) { Text("JOIN ROOM") }
                    }
                }
                Text(status, color = Color.DarkGray, fontSize = 13.sp)
            } else {
                Text("ROOM ID", color = Color.Gray, fontWeight = FontWeight.Bold)
                Text(roomId, fontSize = 34.sp, fontWeight = FontWeight.Black, color = Navy)
                OutlinedButton(onClick = { status = "Room ID: $roomId — share this code with friends." }) { Text("Show invite code") }
                Text("Players (${players.size}/4)", fontWeight = FontWeight.Bold, color = Navy)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Red, Blue, Green, Yellow).forEachIndexed { i, color ->
                        Box(Modifier.weight(1f).height(52.dp).background(color.copy(alpha = if (i < players.size) 1f else 0.25f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Text(if (i < players.size) players[i].take(8) else listOf("Red", "Blue", "Green", "Yellow")[i], fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (i == 3 && i < players.size) Navy else Color.White)
                        }
                    }
                }
                LudoBoard(tokens)
                Text("Dice: $dice", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                Button(onClick = {
                    dice = Random.nextInt(1, 7)
                    val next = tokens.toMutableList()
                    next[currentTurn] = (next[currentTurn] + dice).coerceAtMost(57)
                    tokens = next
                    status = "Demo move updated. Full Ludo rules and online sync are not yet connected."
                    currentTurn = (currentTurn + 1) % 4
                }, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("ROLL DICE") }
                Text(status, fontSize = 12.sp, color = Color.DarkGray)
                TextButton(onClick = { screen = "home"; status = "Create a room or enter your friend's Room ID." }) { Text("Back to Home") }
            }
        }
    }
}

@Composable
fun LudoBoard(tokens: List<Int>) {
    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val colors = listOf(Red, Blue, Green, Yellow)
        for (r in 0 until 7) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (c in 0 until 7) {
                    val idx = when {
                        r < 3 && c < 3 -> 0
                        r < 3 && c > 3 -> 1
                        r > 3 && c > 3 -> 2
                        r > 3 && c < 3 -> 3
                        else -> -1
                    }
                    val cellColor = if (idx >= 0) colors[idx].copy(alpha = 0.9f) else if (r == 3 || c == 3) Color(0xFFE5E7EB) else Color(0xFFF8FAFC)
                    Box(Modifier.weight(1f).aspectRatio(1f).background(cellColor, RoundedCornerShape(3.dp)), contentAlignment = Alignment.Center) {
                        if (idx >= 0 && r in listOf(1, 2, 4, 5) && c in listOf(1, 2, 4, 5)) {
                            if ((r + c) % 2 == 0) Text("●", color = Color.White, fontSize = 16.sp)
                        } else if (r == 3 && c == 3) Text("★", color = Navy, fontSize = 18.sp)
                        else if ((r == 3 || c == 3) && (r + c) % 2 == 0) Text("•", color = Navy, fontSize = 15.sp)
                    }
                }
            }
        }
        Text("Prototype board — full classic 15×15 board and rules are next implementation steps.", fontSize = 10.sp, color = Color.Gray)
    }
}
