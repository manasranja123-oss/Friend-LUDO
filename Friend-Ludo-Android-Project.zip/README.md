# Friend Ludo Android

A simple Android WebView wrapper around a local offline Ludo prototype.

## Build
Use JDK 17, Android SDK platform 35, and Gradle 8.9:
```bash
gradle assembleDebug
```

This version is an offline local pass-and-play prototype. Online multiplayer, room IDs, server-side turn validation, full official Ludo rules, QA and Play Store release preparation are not yet implemented.
